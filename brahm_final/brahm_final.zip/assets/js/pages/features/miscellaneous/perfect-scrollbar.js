/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!**************************************************************************!*\
  !*** ../demo11/src/js/pages/features/miscellaneous/perfect-scrollbar.js ***!
  \**************************************************************************/


// Class definition
var KTScrollable = function () {
    
    // Private functions

    // basic demo
    var demo1 = function () {
    }

    return {
        // public functions
        init: function() {
            demo1();
        }
    };
}();

jQuery(document).ready(function() {    
    KTScrollable.init();
});
/******/ })()
;
//# sourceMappingURL=perfect-scrollbar.js.map