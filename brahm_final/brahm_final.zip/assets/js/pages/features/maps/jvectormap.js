/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!**********************************************************!*\
  !*** ../demo11/src/js/pages/features/maps/jvectormap.js ***!
  \**********************************************************/


// Class definition
var KTjVectorMap = function() {

    // Private functions

    var demo1 = function() {
    }

    return {
        // public functions
        init: function() {
            // default charts
            demo1();
        }
    };
}();

jQuery(document).ready(function() {
    KTjVectorMap.init();
});
/******/ })()
;
//# sourceMappingURL=jvectormap.js.map